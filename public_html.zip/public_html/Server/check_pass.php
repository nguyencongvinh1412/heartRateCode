<?php
    // lay ma phong ban tu trang capnhat.php
    $pass = $_REQUEST['pass'];
    // mo ket noi database
    $link = mysqli_connect("localhost","id16619114_heart_rate","heartRate-4124", "id16619114_heart_rate4124");
    if(!$link) {
        echo "Khong ket noi duoc";
    }
    else {
         echo "<div>Ket noi thanh cong</div>";
         // lua chon csdl
        mysqli_select_db($link,'id16619114_heart_rate4124');
        // query du lieu ve voi ma phong ban nhap vao
        $result = mysqli_query($link,"select * from accout where code=$pass");
        // dong ket noi database
        mysqli_close($link);
        
            if(mysqli_num_rows($result) >0)
            {
                while($row = mysqli_fetch_array($result))
                {
                    $fileStatus = file_put_contents ("dataUser.txt", $row[0]);
                    echo "pass đúng";
                }
            }
            else {
                $fileStatus = file_put_contents ("dataUser.txt", "");
                echo "pass sai";
            }
    }
   
?>