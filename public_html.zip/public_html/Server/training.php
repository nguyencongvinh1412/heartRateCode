<?php
    
    $heart = $_GET['heart'];
    $heartNew = $heart;
    $oximeter = $_GET['oximeter'];
    // mo ket noi database
    $link = mysqli_connect("localhost","id16619114_heart_rate","heartRate-4124", "id16619114_heart_rate4124");
    if(!$link) {
        echo "Khong ket noi duoc";
    }
    else {
         echo "<div>Ket noi thanh cong</div>";
        // lua chon csdl
        mysqli_select_db($link,'id16619114_heart_rate4124');
        
        $id_acc = file_get_contents('dataUser.txt');
        $result = mysqli_query($link, "select sex, age, currentSmoker, BPMeds, prevalentStroke, prevalentHyp, diabetes , weight, height from accout where id = $id_acc");
        $tempUser = getArray($result);
        
        $mUser = array();
        $bmi = round(1.0 * $tempUser[7]/($tempUser[8]*$tempUser[8]), 2);
        
        for($i = 0; $i < count($tempUser) -1; $i++) {
            if($i == 7) $mUser[$i] = $bmi;
            else if($i < 7) $mUser[$i] = $tempUser[$i];
        }
        
        //array_push($mUser, $heart);
        
        $male = $mUser[0]; $age = $mUser[1]; $smoker = $mUser[2]; $bpmeds = $mUser[3]; $prevalentStroke = $mUser[4]; $prevalentHyp = $mUser[5]; $diabetes = $mUser[6]; $bmi = $mUser[7]; 
        
            // count samples
            $result = mysqli_query($link,"select count(*) from framingham");
            if(mysqli_num_rows($result) > 0) {
                $total = getValue($result);
            }

            // sick
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1");
            if(mysqli_num_rows($result) > 0) {
                $sick = getValue($result);
            }

            // male
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and male = '$male' ");
            if(mysqli_num_rows($result) > 0) {
                $sickMale = getValue($result);
            }

            //age
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and age = '$age' ");
            if(mysqli_num_rows($result) > 0) {
                $sickAge = getValue($result);
            }

            // smoker
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and currentSmoker ='$smoker' ");
            if(mysqli_num_rows($result) > 0) {
                $sickSmoker = getValue($result);
            }

            // bpmeds
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and BPMeds = '$bpmeds' ");
            if(mysqli_num_rows($result) > 0) {
                $sickBPMeds = getValue($result);
            }

            // prevalentStroke
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and prevalentStroke ='$prevalentStroke'");
            if(mysqli_num_rows($result) > 0) {
                $sickPrevalentStroke = getValue($result);
            }

            // prevalentHyp
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and prevalentHyp = '$prevalentHyp' ");
            if(mysqli_num_rows($result) > 0) {
                $sickPrevalentHyp = getValue($result);
            }

            // diabetes
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and diabetes = '$diabetes'");
            if(mysqli_num_rows($result) > 0) {
                $sickDiabetes = getValue($result);
            }

            // bmi
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and BMI = '$bmi'");
            if(mysqli_num_rows($result) > 0) {
                $sickBMI = getValue($result);
            }

            // heart
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and heartRate = '$heart'");
            if(mysqli_num_rows($result) > 0) {
                $sickHeart = getValue($result);
            }
            

            /**----------------------- */
            // ko bệnh
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0");
            if(mysqli_num_rows($result) > 0) {
                $noSick = getValue($result);
            }

            // male
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and male = '$male' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickMale = getValue($result);
            }

            //age
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and age = '$age' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickAge = getValue($result);
            }

            // smoker
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and currentSmoker ='$smoker' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickSmoker = getValue($result);
            }

            // bpmeds
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and BPMeds = '$bpmeds' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickBPMeds = getValue($result);
            }

            // prevalentStroke
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and prevalentStroke ='$prevalentStroke'");
            if(mysqli_num_rows($result) > 0) {
                $noSickPrevalentStroke = getValue($result);
            }

            // prevalentHyp
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and prevalentHyp = '$prevalentHyp' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickPrevalentHyp = getValue($result);
            }

            // diabetes
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and diabetes = '$diabetes'");
            if(mysqli_num_rows($result) > 0) {
                $noSickDiabetes = getValue($result);
            }

            // bmi
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and BMI = '$bmi'");
            if(mysqli_num_rows($result) > 0) {
                $noSickBMI = getValue($result);
            }

            // heart
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and heartRate = '$heart'");
            if(mysqli_num_rows($result) > 0) {
                $noSickHeart = getValue($result);
            }
            

            $male = brobability($sickMale, $sick);
            $age = brobability($sickAge, $sick);
            $smoker = brobability($sickSmoker, $sick);
            $bpmeds = brobability($sickBPMeds, $sick);
            $prevalentStroke = brobability($sickPrevalentStroke, $sick);
            $prevalentHyp = brobability($sickPrevalentHyp, $sick);
            $diabetes = brobability($sickDiabetes, $sick);
            $bmi = brobability($sickBMI, $sick);
            $heart = brobability($sickHeart, $sick);

            $tick = $male * $age * $smoker * $bpmeds * $prevalentStroke * $prevalentHyp * $diabetes * $bmi * $heart;
            $retSick = $tick * $sick / $total;

            // No sick
            $male = brobability($noSickMale,$noSick);
            $age = brobability($noSickAge,$noSick);
            $smoker = brobability($noSickSmoker,$noSick);
            $bpmeds = brobability($noSickBPMeds,$noSick);
            $prevalentStroke = brobability($noSickPrevalentStroke,$noSick);
            $prevalentHyp = brobability($noSickPrevalentHyp,$noSick);
            $diabetes = brobability($noSickDiabetes,$noSick);
            $bmi = brobability($noSickBMI,$noSick);
            $heart = brobability($noSickHeart,$noSick);

            $tick = $male * $age * $smoker * $bpmeds * $prevalentStroke * $prevalentHyp * $diabetes * $bmi * $heart;
            $retNoSick = $tick * $noSick / $total;
            
            $value;
            if($retSick > $retNoSick) $value = 1;
            else $value = 0;
            
            echo '<br>' . $value;
            
        $result = mysqli_query($link, "select cigsPerDay, weight, height from accout where id = $id_acc");
        $tempUser = getArray($result);
        
        $mUser = array();
        $bmi = round(1.0 * $tempUser[1]/($tempUser[2]*$tempUser[2]), 2);
        for($i = 0; $i < count($tempUser) -1; $i++) {
            if($i == 1) $mUser[$i] = $bmi;
            else if($i < 1) $mUser[$i] = $tempUser[$i];
        }
        
        
        array_push($mUser, $value);
        array_unshift($mUser, $heartNew);
        
        
        // xử lý để chọn recommend tương ứng
        $ArrRecommend = array();
        for($i = 0; $i < count($mUser); $i++) {
            switch($i) {
                case 0: 
                    if($mUser[$i] <=100) $ArrRecommend[$i] = 0;
                    else if($mUser[$i] >=101 && $mUser[$i] <=150) $ArrRecommend[$i] = 1;
                    else if($mUser[$i] >=151 && $mUser[$i] <=200) $ArrRecommend[$i] = 2;
                    else if($mUser[$i] >=201) $ArrRecommend[$i] = 3;
                    break;
                case 1: 
                    if($mUser[$i] >=0 && $mUser[$i] <=10) $ArrRecommend[$i] = 0;
                    else if($mUser[$i] >=11 && $mUser[$i] <=20) $ArrRecommend[$i] = 1;
                    else if($mUser[$i] >=21 && $mUser[$i] <=30) $ArrRecommend[$i] = 2;
                    else if($mUser[$i] >=31) $ArrRecommend[$i] = 3;
                    break;
                case 2: 
                    if($mUser[$i] < 18.5) $ArrRecommend[$i] = -1;
                    else if($mUser[$i] >=18.5 && $mUser[$i] <=24.9) $ArrRecommend[$i] = 0;
                    else if($mUser[$i] >=25 && $mUser[$i] <=29.9) $ArrRecommend[$i] = 1;
                    else if($mUser[$i] >=30 && $mUser[$i] <= 34.9) $ArrRecommend[$i] = 2;
                    else if($mUser[$i] > 35) $ArrRecommend[$i] = 3;
                    break;
                case 3: 
                    $ArrRecommend[$i] = $mUser[$i];
                    break;
            }
        }
        
        $result = mysqli_query($link, "select ID, RecommendLCD from suc_khoe where Heart_rate = $ArrRecommend[0] and 
            Smoker = $ArrRecommend[1] and BMI = $ArrRecommend[2] and Sick = $ArrRecommend[3] ");
        
        $res = getArray($result);
        
        echo $res[1];
        file_put_contents("dataRecommend.txt", $res[1]);
        
        // lưu dữ liệu vào bảng userRecord
        $result = mysqli_query($link, "select id, sex, age, currentSmoker, cigsPerDay, BPMeds, prevalentStroke, prevalentHyp, diabetes from accout where id = $id_acc");
        
        $result = getArray($result);
        
        array_push($result, $bmi, $heartNew, $oximeter, $value, $res[0]);
        
        $ret = mysqli_query($link, "insert into userrecord(id_acc, sex, age, currentSmoker, cigsPerDay, BPMeds, prevalentStroke, prevalentHyp, diabetes, BMI, heartRate, oximeter, prediction, id_recommend, timeCreate) values('$result[0]', '$result[1]', '$result[2]', '$result[3]', '$result[4]', '$result[5]', '$result[6]', '$result[7]', '$result[8]', '$result[9]', '$result[10]', '$result[11]', '$result[12]', '$result[13]', now())");
    
        // insert data vào data_training
        // $ret = mysqli_query($link,"insert into framingham(male, age, currentSmoker, cigsPerDay, BPMeds, prevalentStroke, prevalentHyp, diabetes, BMI, heartRate,TenYearCHD) values('$result[1]','$result[2]','$result[3]', '$result[4]', '$result[5]', '$result[6]', '$result[7]', '$result[8]', '$result[9]', '$result[10]', '$result[12]')");
    
        mysqli_close($link);
    }
    
    function brobability($x, $xi) {
        $ret = 1.0*($x + 1)/ ($xi + 9);
        return $ret;
    }
    
    function getValue($data) {
        $returnMatrix = array();
        $i = 0;
        while($row = mysqli_fetch_array($data)) {
            $returnMatrix[$i] = array();
            for($j =0 ; $j < count($row)/2; $j++) {
                $returnMatrix[$i][$j] = $row[$j];
            }
            $i++;
        }
        return $returnMatrix[0][0];
    }
    
    function getMatrix($data) {
        $returnMatrix = array();
        $i = 0;
        while($row = mysqli_fetch_array($data)) {
            $returnMatrix[$i] = array();
            for($j =0 ; $j < count($row)/2; $j++) {
                $returnMatrix[$i][$j] = $row[$j];
            }
            $i++;
        }
        return $returnMatrix;
    }
    
    function showMatrix($data) {
        foreach($data as $row) {
            foreach($row as $val) {
                echo $val . "&nbsp&nbsp&nbsp";
            }
            echo "<br>";
        }
    }
    
    function getArray($data) {
        $returnArr = array();
        $i = 0;
        while($row = mysqli_fetch_array($data)) {
            for($i = 0; $i < count($row)/2; $i++) {
                $returnArr[$i] = $row[$i];
            }
        }
        return $returnArr;
    }
?>
