<?php
    session_start();
    include_once('../Model/E_Accout.php');
    include_once('../Model/M_Accout.php');

    // login
    if(isset($_POST['email']) && isset($_POST['pass'])) {
        $acc = new Model_Accout();
        if($acc->login($_POST['email'], $_POST['pass'])) {
            if($_SESSION['level'] == 0) header("Location:../View/quanli.php");
            else header("Location:../View/user.php");
        }
        else {
            header("Location:../View/login.php?errorLogin=error");
        }
    }

    // logout user
    else if(isset($_GET['keyLogout'])) {
        $acc = new Model_Accout();
        $acc->logout();
        header("Location:../View/index.php");
    }

    // dang ky Accout
    else if(isset($_POST['emailRegister'])) {
        $acc = new Model_Accout();
        $result = $acc->register(1, $_POST['emailRegister'], $_POST['passRegister'], $_POST['male'], 
            $_POST['age'], $_POST['weight'], $_POST['height'], $_POST['currentSmoker'], $_POST['cigsPerDay'], 
            $_POST['BPMeds'], $_POST['prevalentStroke']
            , $_POST['prevalentHyp'], $_POST['diabetes']);
        if($result === 'emailRegister') {
            header("Location:../View/register.php?emailRegister=error");
        }
        else if($result) {
                header("Location:../View/user.php");
        }
        else {
            header("Location:../View/register.php");
        }
    }

    // lấy danh sách accout 
    else if(isset($_GET['quanlidanhsach'])) {
        $acc = new Model_Accout();
        $arr = $acc->getAllAccout();
        include('../View/quanlidanhsach.php');
    }

    // thêm user từ phía admin
    else if(isset($_POST['emailAdd'])) {
        $acc = new Model_Accout();
        $result = $acc->register(1, $_POST['emailAdd'], $_POST['passAdd'], $_POST['male'], 
            $_POST['age'], $_POST['weight'], $_POST['height'], $_POST['currentSmoker'], $_POST['cigsPerDay'], 
            $_POST['BPMeds'], $_POST['prevalentStroke']
            , $_POST['prevalentHyp'], $_POST['diabetes']);
        
        if($result === 'emailRegister') {
            header("Location:../View/themUser.php?AddError=error");
        }
        else if($result) {
            header("Location:../View/themUser.php?AddSuccess=error");
        }
        else header("Location:../View/themUser.php?Add=error");
    }

    // hiển thị thông tin chi tiết accout phía admin
    else if(isset($_GET['chitiet'])) {
        $code = $_GET['chitiet'];
        $acc = new Model_Accout();
        $user = $acc->getUser($code);
        include("../View/chitiet.php");
    }

    // update user phía admin 
    else if(isset($_POST['emailUpdate'])) {
        $code = $_POST['code'];
        $email = $_POST['emailUpdate'];
        $pass= $_POST['passUpdate'];
        $sex = $_POST['male'];
        $age = $_POST['age'];
        $weight = $_POST['weight'];
        $height = $_POST['height'];
        $currentSmoker = $_POST['currentSmoker'];
        $cigsPerDay = $_POST['cigsPerDay'];
        $BPMeds = $_POST['BPMeds'];
        $prevalentStroke = $_POST['prevalentStroke'];
        $prevalentHyp = $_POST['prevalentHyp'];
        $diabetes = $_POST['diabetes'];

        $acc = new Model_Accout();
        $result = $acc->update($email, $pass, $sex, $age, $weight, $height, $currentSmoker, $cigsPerDay, $BPMeds, $prevalentStroke, $prevalentHyp, $diabetes, $code);

        header("Location:../Controller/C_Accout.php?chitiet=$code");
    }

    // xóa user
    else if(isset($_GET['code'])) {
        $code = $_GET['code'];
        $acc = new Model_Accout();
        $result = $acc->delete($code);
        header("Location:../Controller/C_Accout.php?quanlidanhsach=dansach");
    }

    // hiện lịch sử đo 
    else if(isset($_GET['lichsudo'])) {
        $acc = new Model_Accout();
        $arr = $acc->getAllAccout();
        include('../View/lichsudo.php');
    }
?>