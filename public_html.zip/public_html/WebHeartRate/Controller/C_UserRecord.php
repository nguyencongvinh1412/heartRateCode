<?php
    session_start();
    include_once("../Model/E_UserRecord.php");
    include_once("../Model/M_UserRecord.php");

    // lấy danh sách user record theo id_acc
    if(isset($_GET['id'])) {
        $id_acc = $_GET['id'];
        $userRecord = new Model_UserRecord();
        $arr = $userRecord->getRecordAcc($id_acc);
        include("../View/bieudodo.php");
    }
?>