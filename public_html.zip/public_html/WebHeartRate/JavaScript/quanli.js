  $( ".button" ).click(function() {
      $(this).toggleClass( "active" );
      $(".icons").toggleClass( "open" );
    });