<?php
    class Entity_Accout {
        public $id;
        public $level;
        public $name;
        public $pass;
        public $sex;
        public $age;
        public $weight;
        public $height;
        public $currentSmoker;
        public $cigsPerDay;
        public $BPMeds;
        public $prevalentStroke;
        public $prevalentHyp;
        public $diabetes;
        public $code;
        
        public function __construct($_id, $_level, $_name, $_pass, $_sex, $_age, $_weight, $_height, 
            $_currentSmoker, $_cigsPerDay, $_BPMeds, $_prevalentStroke, $_prevalentHyp, $_diabetes, $_code) {
                $this->id = $_id;
                $this->level = $_level;
                $this->name = $_name;
                $this->pass = $_pass;
                $this->sex = $_sex;
                $this->age = $_age;
                $this->weight = $_weight;
                $this->height = $_height;
                $this->currentSmoker = $_currentSmoker;
                $this->cigsPerDay = $_cigsPerDay;
                $this->prevalentStroke = $_prevalentStroke;
                $this->prevalentHyp = $_prevalentHyp;
                $this->diabetes = $_diabetes;
                $this->code = $_code;
        }
    }
?>