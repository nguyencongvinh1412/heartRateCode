<?php
    class Entity_UserRecord {
        public $id;
        public $sex;    
        public $age;
        public $currentSmoker;
        public $cigsPerDay;
        public $BPMeds;
        public $prevalentStroke;
        public $prevalentHyp;
        public $diabetes;
        public $BMI;
        public $heartRate;
        public $oximeter;
        public $prediction;
        public $recommend;
        public $timeCreate;

        public function __construct($id, $sex, $age, $currentSmoker, $cigsPerDay, $BPMeds, $prevalentStroke, $prevalentHyp,
            $diabetes, $BMI, $heartRate, $oximeter, $prediction, $recommend, $timeCreate) {
                $this->id = $id;
                $this->sex = $sex;
                $this->age = $age;
                $this->currentSmoker = $currentSmoker;
                $this->cigsPerDay = $cigsPerDay;
                $this->prevalentStroke = $prevalentStroke;
                $this->prevalentHyp = $prevalentHyp;
                $this->diabetes = $diabetes;
                $this->BMI = $BMI;
                $this->heartRate = $heartRate;
                $this->oximeter = $oximeter;
                $this->prediction = $prediction;
                $this->recommend = $recommend;
                $this->timeCreate = $timeCreate;
            }
    }
?>