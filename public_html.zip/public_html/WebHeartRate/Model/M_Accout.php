<?php
    //include_once("./E_Accout.php");
    class Model_Accout {
        public function __construct() {}

        // login
        public function login($username, $password) {
            require("connectSQL.php");
            $ret = mysqli_query($link, "select * from accout where name= '$username' and pass = '$password'");
            if(mysqli_num_rows($ret) > 0 ) {
                while($row = mysqli_fetch_assoc($ret)) {
                    $_SESSION['level'] = $row["level"];
                    $_SESSION['id'] = $row["id"];
                    $_SESSION['username'] = $row["name"];
                    $_SESSION['code'] = $row['code'];
                }
            }
            if(isset($_SESSION['level'])) return true;
            else return false;
            mysqli_close($link);
        }
        // logout
        public function logout() {
            unset($_SESSION['username']);
            unset($_SESSION['id']);
            unset($_SESSION['level']);
            unset($_SESSION['code']);
        }
        // register
        public function register($level, $username, $password, $sex, $age, $weight, $height, $currentSmoker, $cigsPerDay, $BPMeds, $prevalentStroke, $prevalentHyp, $diabetes) {
                
                require("connectSQL.php");
                $ret = mysqli_query($link, "select name from accout where name = '$username'");
                if(mysqli_num_rows($ret) > 0) {
                    return 'emailRegister';
                }
                
                $ret = mysqli_query($link, "select code from accout");
                $checkCode = true;
                $random;
                do {
                    $checkCode = true;
                    $random = rand(1000, 9999);
                    while($row = mysqli_fetch_array($ret)) {
                        if($random == $row[0]) $checkCode = false;
                    }
                }while($checkCode == false); 

                $ret = mysqli_query($link, "insert into accout(level, name, pass, sex, age, weight, height, currentsmoker, cigsPerDay, BPMeds, prevalentStroke, prevalentHyp, diabetes, code) values('$level', '$username', '$password', '$sex', '$age', '$weight', '$height', '$currentSmoker', '$cigsPerDay', '$BPMeds', '$prevalentStroke', '$prevalentHyp', '$diabetes', '$random')");
                
                $checkInsert = false;
                if($ret) {
                    $checkInsert = true;
                }
                else $checkInsert = false;
                mysqli_close($link);

                return $checkInsert;
        }

        // lấy tất cả accout
        public function getAllAccout() {
            require("connectSQL.php");
            $ret = mysqli_query($link, "select * from accout");
            if(mysqli_num_rows($ret) > 0) {
                $arr = array();
                $i = 0;
                while($row = mysqli_fetch_assoc($ret
                )) {
                    $arr[$i] = new Entity_Accout($row['id'], $row['level'], $row['name'], $row['pass'], $row['sex'], $row['age'], $row['weight'], $row['height']
                        , $row['currentSmoker'], $row['cigsPerDay'], $row['BPMeds'], $row['prevalentStroke'], $row['prevalentHyp'], $row['diabetes'], $row['code']);
                    $i++;
                }
            }
            return $arr;
        }

        // lấy 1 accout theo mã code
        public function getUser($code) {
            require("connectSQL.php");
            $ret = mysqli_query($link, "select * from accout where code = '$code'");
            if(mysqli_num_rows($ret) > 0) {
                while($row = mysqli_fetch_assoc($ret)) {
                    $user = new Entity_Accout($row['id'], $row['level'], $row['name'], $row['pass'], $row['sex'], $row['age'],
                        $row['weight'], $row['height'], $row['currentSmoker'], $row['cigsPerDay'], $row['BPMeds'],
                        $row['prevalentStroke'], $row['prevalentHyp'], $row['diabetes'], $row['code']);
                }

                mysqli_close($link);
                return $user;
            }
        }

        // update user
        public function update($email, $pass, $sex, $age, $weight, $height, $currentSmoker, $cigsPerDay, $BPMeds, $prevalentStroke, $prevalentHyp, $diabetes, $code) {
            require("connectSQL.php");

            $ret = mysqli_query($link, "select * from accout where name = '$email' and code not like '$code'");
            if(mysqli_num_rows($ret) > 0) {
                return 'emailError';
            }

            $ret = mysqli_query($link, "update accout set name ='$email', pass = '$pass', sex = '$sex', age = '$age', weight = '$weight', height = '$height', 
                currentSmoker = '$currentSmoker', cigsPerDay = '$cigsPerDay', BPMeds = '$BPMeds', prevalentStroke = '$prevalentStroke', prevalentHyp = '$prevalentHyp', diabetes = '$diabetes' where code = '$code'");
            
            return $ret;
        }

        // xóa user
        public function delete($code) {
            require("connectSQL.php");
            $ret = mysqli_query($link, "delete from accout where code = '$code'");
            mysqli_close($link);
        }
    }
?>