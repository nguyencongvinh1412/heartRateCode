<?php
    class Model_UserRecord {
        public function __construct() {}

        // lấy tất cả record theo id_acc
        public function getRecordAcc($id_acc) {
            require("connectSQL.php");
            $ret = mysqli_query($link, "select * from userrecord where id_acc = '$id_acc'");
            $arrRecommend = array();
            $i = 0;
            if(mysqli_num_rows($ret) > 0) {
                while($row = mysqli_fetch_assoc($ret)) {
                    $idRecommend = $row['id_recommend'];
                    $recommend = mysqli_query($link, "select Recommend from suc_khoe where ID = '$idRecommend'");
                    if(mysqli_num_rows($recommend) > 0) {
                        while($re = mysqli_fetch_assoc($recommend)) {
                            $rec = $re['Recommend'];
                        }
                    }

                    $arrRecommend[$i] = new Entity_UserRecord($row['id'], $row['sex'], $row['age'], $row['currentSmoker'],
                        $row['cigsPerDay'], $row['BPMeds'],$row['prevalentStroke'], $row['prevalentHyp'],
                        $row['diabetes'], $row['BMI'], $row['heartRate'], $row['oximeter'], $row['prediction'], $rec, $row['timeCreate']);
                    $i++;
                }
            }

            return $arrRecommend;
        }
    }
?>