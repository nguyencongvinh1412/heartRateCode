<?php
    $link = mysqli_connect("localhost","id16619114_heart_rate","heartRate-4124", "id16619114_heart_rate4124");
    mysqli_select_db($link,'id16619114_heart_rate4124');
?>