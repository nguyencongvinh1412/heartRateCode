<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Chi tiết</title>
	<!-- Load font awesome -->
	<link rel="stylesheet" href="assets/vendors/font-awesome-4.7.0/css/font-awesome.min.css">

	<!-- Load google font -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" rel="stylesheet">

	<!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.2.0/chart.min.js"></script>

    <style>
        .table-recommend{
            width: 80%;
            height: 100%;
            margin: auto;
            padding: 100px;
            border: 1px solid green;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <?php
		if($_SESSION['level'] == 0)
			include("../View/tieudequanli.php"); 
		else include("../View/tieude.php");
	?>
	<div style="width:1000px; height:500px; margin:auto; margin-top:100px">
        <canvas id="canvas"></canvas>
    </div>

    <div style="width:500px; height:500px; margin:auto; margin-top:100px">
        <canvas id="canvas-tongquan"></canvas>
    </div>

    <?php
        $heart = array();
        $oxi = array();
        $time = array();
        $pre = array();
        foreach ($arr as $record) {
            array_push($heart, $record->heartRate);
            array_push($oxi, $record->oximeter);
            array_push($time, $record->timeCreate);
            array_push($pre, $record->prediction);
        }

    ?>
    <script>
        var heart = <?php echo json_encode($heart); ?>;
        var oxi = <?php echo json_encode($oxi); ?>;
        var time = <?php echo json_encode($time); ?>;
        var charjs = document.getElementById('canvas').getContext('2d');
        var line_chart = new Chart(charjs, {
            type: 'line',
            data: {
                labels: time,
                datasets: [
                    {
                        label: 'Nhịp Tim(Heart Rate)',
                        data: heart,
                        borderColor: '#ff6384',
                        backgroundColor: '#ff6384',
                        yAxisID: 'y'
                    },
                    {
                        label: 'Oxi trong máu(Oximeter)',
                        data: oxi,
                        borderColor: '#36a2eb',
                        backgroundColor: '#36a2eb',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                stacked: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Biểu đồ nhịp tim - oxi trong máu'
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',

                        // grid line settings
                        grid: {
                        drawOnChartArea: false, // only want the grid lines for one axis to show up
                        },
                    },
                }
            },
        });

    </script>

    <!-- cấu hình biểu đồ kết quả tổng quan -->
    <script>
        var pre = <?php echo json_encode($pre); ?>;
        var heartYes = [];
        var heartNo = [];
        for(var item of pre) {
            if (item == 0) heartNo.push(item);
            else if(item == 1) heartYes.push(item);
        }
        var ret = [100.0 *heartNo.length/pre.length, 100.0*heartYes.length/ pre.length];
        console.log(ret);
        var char_doughnut = document.getElementById('canvas-tongquan').getContext('2d');
        var line_chart = new Chart(char_doughnut, {
            type: 'doughnut',
            data: {
                labels: ['Không có nguy cơ bệnh tim', 'Có nguy cơ bệnh tim'],
                datasets: [
                    {
                        label: ['Không có nguy cơ bệnh tim', 'Có nguy cơ bệnh tim'],
                        data: ret,
                        backgroundColor: ['#36a2eb','#ff6384']
                    },
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Biểu đồ tổng quan về kết quả đo'
                    }
                }
            },
    });

    </script>

    <br>
    <table class="table table-striped table-recommend">
        <thead>
            <tr>
                <th>ID</th>
                <th>Giới Tính</th>
                <th>Tuổi</th>
                <th>Số điếu thuốc/Ngày</th>
                <th>Dùng thuốc Tăng huyết áp</th>
                <th>Tiền sử đột quỵ</th>
                <th>Tiền sử bệnh tăng huyết áp</th>
                <th>Bệnh tiểu đường</th>
                <th>BMI</th>
                <th>Nhịp tim</th>
                <th>Oxi trong máu</th>
                <th>Dự đoán</th>
                <th>Recommend</th>
            </tr>
        </thead>
        <tbody>
            <?php
                foreach($arr as $item) {
                    $sex = $item->sex == 1 ? 'Nam' : 'Nữ';
                    $bpmeds = $item->BPMeds == 0 ? 'Không' : 'Có';
                    $Stroke = $item->prevalentStroke == 0 ? 'Không' : 'Có';
                    $Hyp = $item->prevalentHyp == 0 ? 'Không' : 'Có';
                    $diabetes = $item->diabetes == 0 ? 'Không' : 'Có';
                    $pre = $item->prediction == 0 ? 'Không' : 'Có';
                    echo
                    "
                        <tr>
                            <td>$item->id</td>
                            <td>$sex</td>
                            <td>$item->age</td>
                            <td>$item->cigsPerDay</td>
                            <td>$bpmeds</td>
                            <td>$Stroke</td>
                            <td>$Hyp</td>
                            <td>$diabetes</td>
                            <td>$item->BMI</td>
                            <td>$item->heartRate</td>
                            <td>$item->oximeter</td>
                            <td>$pre</td>
                            <td>$item->recommend</td>
                        </tr>
                    ";
                }
            ?>
        </tbody>
    </table>
</body>

</html>