<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Chi tiết</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
	<!-- Load font awesome -->
	<link rel="stylesheet" href="assets/vendors/font-awesome-4.7.0/css/font-awesome.min.css">

	<!-- Load google font -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" rel="stylesheet">

	<!-- Load main stylesheet -->
	<link rel="stylesheet" href="../styleCSS/capnhat.css">

    <style>
        .btn {
            width: 100%;
            margin-top: 20px;
            border: none;
            background: #1abc9c;
            cursor: pointer;
            border-radius: 3px;
            padding: 6px;
            width: 200px;
            color: white;
            box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.2);
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 6px 0 rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body>
    <?php
		if($_SESSION['level'] == 0)
			include("../View/tieudequanli.php"); 
		else include("../View/tieude.php");
	?>
	<form action="../Controller/C_Accout.php" method="post">
		<table>
            <tr>
                <td>
                    Code:
                </td>
                <td>
                    <input type="text" value="<?php echo $user->code?>" readonly name="code">
                </td>
            </tr>

        <tr>
				<td>
					Email:
				</td>
				<td class="form-group">
					<input type="text" required="" name="emailUpdate" id="emailUpdate" value="<?php echo $user->name ?>">
					<span class="form-message"></span>
				</td>
				<td>
					Password:
				</td>
				<td class="form-group">
					<input type="text" required="" name="passUpdate" id="passUpdate" value="<?php echo $user->pass?>">
					<span class="form-message"></span>
				</td>
				<td>
					Giới tính:
				</td>
				<td>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" id="male" class="form-check-input" name="male" value="1"
                            <?php 
                                if($user->sex == 1) echo 'checked';
                            ?>
                        >
						Nam 
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="male" value="0"
                            <?php 
                                if($user->sex == 0) echo 'checked';
                            ?>
                        >
						Nữ
						</label>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					Tuổi:
				</td>
				<td class="form-group">
					<input type="text" required="" name="age" id="age" value="<?php echo $user->age?>">
					<span class="form-message"></span>
				</td>
				<td>
					Chiều cao:
				</td>
				<td class="form-group">
					<input type="text" required="" name="height" id="height" value="<?php echo $user->height?>">
					<span class="form-message"></span>
				</td>
				<td>
					Cân nặng:
				</td>
				<td class="form-group">
					<input type="text" required="" name="weight" id="weight" value="<?php echo $user->weight; ?>">
					<span class="form-message"></span>
				</td>
			</tr>
			<tr>
				<td>
					Hút thuốc:  
				</td>
				<td>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" id="currentSmoker" class="form-check-input" name="currentSmoker" value="1"
                            <?php
                                if($user->currentSmoker == 1) echo 'checked';
                            ?>
                        >
							Có 
						</label>
					</div>

					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="currentSmoker" value="0"
                            <?php
                                if($user->currentSmoker == 0) echo 'checked';
                            ?>
                        >
							Không
						</label>
					</div>
				</td>
				<td>
					Số điếu/Ngày:
				</td>
				<td class="form-group">
					<input type="text" required="" name="cigsPerDay" id="cigsPerDay" value="<?php echo $user->cigsPerDay?>">
					<span class="form-message"></span>
				</td>

				<td>
					Có dùng thuốc tăng huyết áp không?:  
				</td>
				<td>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" id="BPMeds" class="form-check-input" name="BPMeds" value="1"
                            <?php
                                if($user->BPMeds == 1) echo 'checked';
                            ?>
                        >
							Có 
						</label>
					</div>

					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="BPMeds" value="0"
                            <?php
                                if($user->BPMeds == 0) echo 'checked';
                            ?>
                        >
							Không 
						</label>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					Có tiền sử bệnh đột quỵ Không?:  
				</td>
				<td>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" id="prevalentStroke" class="form-check-input" name="prevalentStroke" value="1"
                            <?php
                                if($user->prevalentStroke == 1) echo 'checked';
                            ?>
                        >
							Có 
						</label>
					</div>

					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="prevalentStroke" value="0"
                            <?php
                                if($user->prevalentStroke == 0) echo 'checked';
                            ?>
                        >
							Không 
						</label>
					</div>
				</td>

				<td>
					Có tiền sử bệnh tăng huyết áp không?:  
				</td>
				<td>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" id="prevalentHyp" class="form-check-input" name="prevalentHyp" value="1"
                            <?php
                                if($user->prevalentHyp == 1) echo 'checked';
                            ?>
                        >
							Có 
						</label>
					</div>

					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="prevalentHyp" value="0"
                            <?php
                                if($user->prevalentHyp == 0) echo 'checked';
                            ?>
                        >
							Không 
						</label>
					</div>
				</td>
				<td>
					Có bị bệnh tiểu đường không?:  
				</td>
				<td>
					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" id="diabetes" class="form-check-input" name="diabetes" value="1"
                            <?php
                                if($user->diabetes == 1) echo 'checked';
                            ?>
                        >
							Có 
						</label>
					</div>

					<div class="form-check">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="diabetes" value="0"
                            <?php
                                if($user->diabetes == 0) echo 'checked';
                            ?>
                        >
							Không 
						</label>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="3">
                    <button type="submit">Cập Nhật</button>
				</td>

				<?php 
					if($_SESSION['level'] == 0) {
						echo
						"
							<td colspan=\"3\">
								<a href=\"../Controller/C_Accout.php?code=<?php echo $user->code?>\" class=\"btn\">
									Xóa
								</a>				
							</td>
						";
					}
				?>
			</tr>

		</table>
        
        <?php 
            if(isset($_GET['emailError'])) {
                echo
                "
                    <div class=\"alert alert-danger\" role=\"alert\">
                        <strong>Email này đã tồn tại</strong>
                    </div>
                ";
            }
            else if(isset($_GET['emailSuccess'])) {
                echo
                "
                    <div class=\"alert alert-success\" role=\"alert\">
                        <strong>Update thành công</strong>
                    </div>
                ";
            }
            else if(isset($_GET['Error'])) {
                echo 
                "
                    <div class=\"alert alert-warning\" role=\"alert\">
                        <strong>Lỗi Update</strong>
                    </div>
                ";
            }
        ?>

	</form>
</body>

</html>