<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Liên hệ</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
    integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../styleCSS/contact.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="../styleCSS/tieudequanli.css">
</head>

<body>
  <section>
    <div class="container">
      <div class="containerinfo">
        <div>
          <h2>Thông Tin Liên Hệ</h2>
          <ul class="info">
            <li>
              <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
              <span>54 Nguyễn Lương Bằng<br />
                Quận Liên Chiểu,<br />
                Thành Phố Đà Nẵng
              </span>
            </li>
            <li>
              <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
              <span>heartrate4124@gmail.com</span>
            </li>
            <li>
              <span><i class="fa fa-phone-square" aria-hidden="true"></i></span>
              <span>012-345-6779</span>
            </li>
          </ul>
        </div>
        <ul class="sci">
          <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
          <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
          <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
          <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
          <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        </ul>
      </div>
  </section>
  <footer class="footer-distributed">

    <div class="footer-left">

      <h3>DAVDK<span>group</span></h3>

      <p class="footer-links">
        <a href="#" class="link-1">Trang chủ</a>

        <a href="#">Chúng tôi</a>

        <a href="#">Liên hệ</a>
      </p>

      <p class="footer-company-name">DAVDK © 2021</p>
    </div>

    <div class="footer-center">

      <div>
        <i class="fa fa-map-marker"></i>
        <p><span>Đại học Bách Khoa Đà Nẵng</span> Liên Chiểu, Đà Nẵng</p>
      </div>

      <div>
        <i class="fa fa-phone"></i>
        <p>+8423345779</p>
      </div>

      <div>
        <i class="fa fa-envelope"></i>
        <p><a href="mailto:support@company.com">heartrate4124@gmail.com</a></p>
      </div>

    </div>

    <div class="footer-right">

      <p class="footer-company-about">
        <span>Về Chúng tôi</span>
        DAVĐK luôn đồng hành cùng các bạn, nơi của trách nhiệm và chất lượng!
      </p>

      <div class="footer-icons">

        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
        <a href="#"><i class="fa fa-github"></i></a>

      </div>

    </div>

  </footer>
</body>

</html>