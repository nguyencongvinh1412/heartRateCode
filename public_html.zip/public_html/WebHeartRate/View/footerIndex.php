<footer class="footer-distributed">

			<div class="footer-left">

				<h3>DAVDK<span>group</span></h3>

				<p class="footer-links">
					<a href="#" class="link-1">Trang chủ</a>

					<a href="#">Chúng tôi</a>

					<a href="#">Liên hệ</a>
				</p>

				<p class="footer-company-name">DAVDK © 2021</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Đại học Bách Khoa Đà Nẵng</span> Liên Chiểu, Đà Nẵng</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+8423345779</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">heartrate4124@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>Về Chúng tôi</span>
					DAVĐK luôn đồng hành cùng các bạn, nơi của trách nhiệm và chất lượng!
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					<a href="#"><i class="fa fa-github"></i></a>

				</div>

			</div>

		</footer>