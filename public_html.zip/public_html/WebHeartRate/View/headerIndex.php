<header>
	<h1>Let's show your heart rate!</h1>
	<nav class="hea">
	    <a href="index.php">Trang chủ</a>
		<a href="login.php">Đăng nhập</a>
		<a href="contact.php">Chúng tôi</a>

	</nav>
</header>