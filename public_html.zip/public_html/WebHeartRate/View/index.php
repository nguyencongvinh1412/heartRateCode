<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Trang chủ</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
		integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../styleCSS/style.css">
</head>

<body>
	<div class="container">
		<!--Header -->
		<?php include("./headerIndex.php") ?>
		<!--End Header -->

		<!--Body -->
		<main>
			<article>
				<h3>Một số bệnh thường gặp</h3>
				<div class="new_list">
					<div class="news_item">
						<h4>
							Bệnh tim mạch vành
						</h4>
						<img src="../picture/benh1.jpg" alt="">
						<div class="content">
							Cảm giác nặng ngực, khó thở.
							Xuất hiện cơn đau thắt ngực bên trái khi xúc động, gắng sức. Cơn đau thường xuất hiện vào
							buổi sáng.
							Nhức đầu, chóng mặt.
						</div>
					</div>
					<div class="news_item">
						<h4>
							Bệnh viêm cơ tim
						</h4>
						<img src="../picture/benh4.jpg" alt="">
						<div class="content">
							Ở giai đoạn đầu, bệnh thường không có dấu hiệu và triệu chứng.
							Khi tiến triển nặng, triệu chứng có thể là: khó thở, đau ngực, sưng chân, huyết áp cao,
							chóng mặt.
						</div>
					</div>
					<div class="news_item" id="fix">
						<h4>
							Thiếu máu cơ tim
						</h4>
						<img src="../picture/benh3.jpg" alt="">
						<div class="content">
							Xuất hiện cơn đau vùng ngực.
							Nhịp tim nhanh.
							Khó thở khi vận động
						</div>
					</div>
				</div>
			</article>
			<a href="https://careplusvn.com/vi/7-benh-tim-mach-thuong-gap-va-cac-trieu-chung-dien-hinh">Xem thêm</a>

			<article>
				<h3>Chuyên gia</h3>
				<div class="new_list">
					<div class="news_item">
						<h4>
							Bác sĩ Phạm Gia Khải
						</h4>
						<img src="../picture/bs4.jpg" alt="">
						<div class="content">
							Chuyên gia Tim mạch đầu ngành cao cấp tại Việt Nam, bác sĩ Tim mạch nổi tiếng
							Nguyên Chủ tịch Hội Tim mạch học Việt Nam
							Nguyên là Viện trưởng Viện Tim mạch Việt Nam
							Nguyên Chủ tịch Hiệp hội Tim mạch Đông Nam Á (2008 - 2010)
						</div>
					</div>
					<div class="news_item">
						<h4>
							Bác sĩ Nguyễn Lân Việt
						</h4>
						<img src="../picture/bs2.jpg" alt="">
						<div class="content">
							Chủ tịch Hội Tim mạch học Việt Nam
							Nguyên Viện trưởng Viện Tim mạch Việt Nam
							Nguyên Hiệu trưởng Trường Đại học Y Hà Nội
						</div>
					</div>
					<div class="news_item" id="fix">
						<h4>
							Phạm Thị Tuyết Nga
						</h4>
						<img src="../picture/bs3.jpg" alt="">
						<div class="content">
							Trưởng khoa C2 (Khoa Điều trị tích cực) – Viện Tim mạch Việt Nam
							Nguyên Phó khoa C6 (Khoa Bệnh lý mạch máu, nhiễm độc thai nghén) – Viện Tim mạch Việt Nam
							Nguyên Giảng viên Khoa Nội Tim mạch – Đại Học Y Hà Nội
						</div>
					</div>
				</div>
			</article>
			<a href="https://bookingcare.vn/cam-nang/8-bac-si-kham-chua-tim-mach-gioi-tai-ha-noi-p20.html">Xem thêm</a>
			<article>
				<h3>các sản phẩm tương tự</h3>
				<div class="new_list">

					<div class="news_item">
						<h4>
							Instant Heart Rate đo nhịp tim bằng cách sử dụng camera và đèn flash của điện thoại
						</h4>
						<img src="../picture/item4.jpg" alt="">
						<div class="content">
							Phiên bản Android hỗ trợ Google Fit.
							Phiên bản iOS có thể đồng bộ với Apple Health.
							Có sẵn trên iOS, Android và Windows Phone.
						</div>
					</div>
					<div class="news_item">
						<h4>
							Ứng dụng theo dõi nhịp tim tốt nhất cho bà mẹ mang thai: My Baby's Beat
						</h4>
						<img src="../picture/item2.jpg" alt="">
						<div class="content">
							Một cách khá thông minh để các bà mẹ kết nối với đứa con sắp chào đời.
							Rất dễ dàng để ghi và phát lại các file âm thanh.
						</div>
					</div>
					<div class="news_item" id="fix">
						<h4>
							Ứng dụng theo dõi tim liên kết với nhiều mạng xã hội nhất: Runtastic Heart Rate
						</h4>
						<img src="../picture/item3.jpg" alt="">
						<div class="content">
							Đồng bộ dữ liệu vào cùng một tài khoản Runtastic được sử dụng trên các ứng dụng khác.
							Dễ dàng chia sẻ dữ liệu nhịp tim trên mạng xã hội và WhatsApp.
						</div>
					</div>
				</div>
			</article>
			<a href="https://quantrimang.com/ung-dung-theo-doi-nhip-tim-170519">Xem thêm</a>

		</main>
		<!--End Body -->

		<!-- Footer -->
		<?php include("./footerIndex.php") ?>
		<!--End Footer-->
	</div>
</body>

</html>