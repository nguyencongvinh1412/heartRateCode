<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Chi tiết</title>
	<!-- Load font awesome -->
	<link rel="stylesheet" href="assets/vendors/font-awesome-4.7.0/css/font-awesome.min.css">

	<!-- Load google font -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" rel="stylesheet">

	<!-- Load main stylesheet -->
	<link rel="stylesheet" href="../styleCSS/capnhat.css">

	<!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</head>

<body>
    <?php include("../View/tieudequanli.php"); ?>
	<form>
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Level</th>
					<th>Email</th>
					<th>Code</th>
				</tr>
			</thead>
			<tbody>
				<?php
					foreach($arr as $val) {
						$level = $val->level == 0 ? 'Admin' : 'User';
						echo
						"	
							<tr>
								<td>$level</td>
								<td>$val->name</td>
								<td><a href=\"../Controller/C_UserRecord.php?id=$val->id\">$val->code</a></td>
							</tr>
						";
					}
				?>
			</tbody>
		</table>
	</form>
</body>

</html>