<!DOCTYPE html>
<html>

<head>
    <title>Đăng nhập</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styleCSS/login.css" rel="stylesheet" type="text/css" />
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <h3>
            ĐĂNG NHẬP
        </h3>
    </header>
    <main>
        <table align="center" style="margin:auto;">
            <tr>
                <td>
                    <div class="container">
                        <div class="login-form">
                            <form action="../Controller/C_Accout.php" method="post">
                                <h1>Đăng nhập</h1>
                                <div class="input-box">
                                    <i></i>
                                    <input type="text" placeholder="Email" name="email">
                                </div>
                                <div class="input-box">
                                    <i></i>
                                    <input type="password" placeholder="Mật khẩu" name="pass">
                                </div>
                                <div class="btn-box-dn">
                                    <button type="submit">
                                        Đăng nhập
                                    </button>
                                </div>
                                <br>
                                <?php 
                                    if(isset($_GET['errorLogin'])) {
                                        echo '<div class="alert alert-danger">
                                                Tên đăng nhập hoặc mật khẩu chưa đúng
                                            </div>';
                                    }
                                ?>
                                <div class="lnk-page">
                                    <a href="#">
                                        Quên mật khẩu?
                                    </a>
                                    <a href="./register.php">
                                        Đăng Ký
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </main>
    
    <footer class="footer-distributed">

        <div class="footer-left">

            <h4>DAVDK<span>group</span></h4>

            <p class="footer-links">
                <a href="#" class="link-1">Trang chủ</a>

                <a href="#">Chúng tôi</a>

                <a href="#">Liên hệ</a>
            </p>

            <p class="footer-company-name">DAVDK © 2021</p>
        </div>

        <div class="footer-center">

            <div>
                <i class="fa fa-map-marker"></i>
                <p><span>Đại học Bách Khoa Đà Nẵng</span> Liên Chiểu, Đà Nẵng</p>
            </div>

            <div>
                <i class="fa fa-phone"></i>
                <p>+8423345779</p>
            </div>

            <div>
                <i class="fa fa-envelope"></i>
                <p><a href="mailto:support@company.com">heartrate4124@gmail.com</a></p>
            </div>

        </div>

        <div class="footer-right">

            <p class="footer-company-about">
                <span>Về Chúng tôi</span>
                DAVĐK luôn đồng hành cùng các bạn, nơi của trách nhiệm và chất lượng!
            </p>

            <div class="footer-icons">

                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-github"></i></a>

            </div>

        </div>

    </footer>
</body>

</html>