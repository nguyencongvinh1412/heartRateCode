<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Chi tiết</title>
    <!-- Load font awesome -->
    <link rel="stylesheet" href="assets/vendors/font-awesome-4.7.0/css/font-awesome.min.css">

    <!-- Load google font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" rel="stylesheet">

    <!-- Load main stylesheet -->
    <link rel="stylesheet" href="../styleCSS/quanliganday.css">
</head>

<body>
    <!--tiêu đề thanh quản lý -->
    <?php include("./tieudequanli.php") ?>
    <form>
        <table>
            <tr>
                <td>
                    Date:
                </td>
                <td>
                    <input type="datetime-local" id="date" name="date">
                </td>
                <td>
                    Mã SV:
                </td>
                <td>
                    <a href="chitiet.html" target="bottom"><strong>0001</strong></a>
                </td>
                <td>
                    Sp02:
                </td>
                <td>
                    <input type="text" required="">
                </td>
                <td>
                    Nhịp tim:
                </td>
                <td>
                    <input type="text" required="">
                </td>
            </tr>
            <tr>
                <td>
                    Date:
                </td>
                <td>
                    <input type="datetime-local" id="date" name="date">
                </td>
                <td>
                    Mã SV:
                </td>
                <td>
                    <a href="chitiet.html" target="bottom"><strong>0002</strong></a>
                </td>
                <td>
                    Sp02:
                </td>
                <td>
                    <input type="text" required="">
                </td>
                <td>
                    Nhịp tim:
                </td>
                <td>
                    <input type="text" required="">
                </td>
            </tr>
            <tr>
                <td>
                    Date:
                </td>
                <td>
                    <input type="datetime-local" id="date" name="date">
                </td>
                <td>
                    Mã SV:
                </td>
                <td>
                    <a href="chitiet.html" target="bottom"><strong>0003</strong></a>
                </td>
                <td>
                    Sp02:
                </td>
                <td>
                    <input type="text" required="">
                </td>
                <td>
                    Nhịp tim:
                </td>
                <td>
                    <input type="text" required="">
                </td>
            </tr>

        </table>


    </form>
</body>

</html>