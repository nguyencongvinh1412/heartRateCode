<!DOCTYPE html>
<html>

<head>
    <title>Đăng Ký</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styleCSS/login.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <h3>
            ĐĂNG KÝ
        </h3>


    </header>
    <main>
        <table align="center" style="margin:auto;">
            <tr>
                <td width="800px">
                    <div class="signup-form">
                        <form action="../Controller/C_Accout.php" method="post" id="form-1" class="form-1">
                            <h1>Đăng ký</h1>
                            <div class="input-box form-group">
                                <i></i>
                                <input type="text" placeholder="Nhập Email" name="emailRegister" value="" id="emailRegister">
                                <span class="form-message"></span>
                            </div>
                            
                            <?php 
                                if(isset($_GET['emailRegister'])) {
                                    echo '<div class="alert alert-danger">
                                            Email này đã tồn tại
                                        </div>';
                                }
                                ?>
                            <div class="input-box form-group">
                                <i></i>
                                <input type="password" placeholder="Nhập mật khẩu" name="passRegister" value="" id="passRegister">
                                <span class="form-message"></span>
                            </div>
                            
                            <div class="input-box form-group">
                                <i></i>
                                <input type="password" placeholder="Nhập lại mật khẩu" value="" id="pass">
                                <span class="form-message"></span>
                            </div>
                            
                            <div class="form-check form-group">
                                <input type="radio" name="male" value="1" checked> Nam 
                                <input type="radio" name="male" value="0"> Nữ
                                <span class="form-message"></span>
                            </div>
                            
                            <br>
                            <div class="input-box form-group">
                                <i></i>
                                <input type="text" placeholder="Nhập tuổi" name="age" value="" id="age">
                                <span class="form-message"></span>
                            </div>
                            
                            <div class="input-box form-group">
                                <i></i>
                                <input type="text" placeholder="Nhập cân năng (Kg)" name="weight" value="" id="weight">
                                <span class="form-message"></span>
                            </div>
                            
                            <div class="input-box form-group">
                                <i></i>
                                <input type="text" placeholder="Nhập chiều cao (m)" name="height" value="" id="height">
                                <span class="form-message"></span>
                            </div>
                            
                            <label>Bạn có hút thuốc không?</label>
                            <div class="form-check form-group">
                                <input type="radio" name="currentSmoker" value="1"> Có
                                <input type="radio" name="currentSmoker" value="0" checked> Không
                                <span class="form-message"></span>
                            </div>
                            
                            <br>
                            <div class="input-box form-group">
                                <i></i>
                                <input type="text" placeholder="Số điếu thuốc/ngày" name="cigsPerDay" value="" id="cigsPerDay">
                                <span class="form-message"></span>
                            </div>
                            
                            <label>Bạn có đang dùng thuốc tăng huyết áp không?</label>
                            <div class="form-check form-group">
                                <input type="radio" name="BPMeds" value="1"> Có
                                <input type="radio" name="BPMeds" value="0" checked> Không
                                <span class="form-message"></span>
                            </div>
                            
                            <br>
                            <label>Bạn có từng bị bệnh đột quỵ không?</label>
                            <div class="form-check form-group">
                                <input type="radio" name="prevalentStroke" value="1"> Có
                                <input type="radio" name="prevalentStroke" value="0" checked> Không
                                <span class="form-message"></span>
                            </div>
                            
                            <br>
                            <label>Bạn có từng bị bệnh tăng huyết áp không?</label>
                            <div class="form-check form-group">
                                <input type="radio" name="prevalentHyp" value="1"> Có
                                <input type="radio" name="prevalentHyp" value="0" checked> Không
                                <span class="form-message"></span>
                            </div>
                            
                            <br>
                            <label>Bạn có bị bệnh tiểu đường không?</label>
                            <div class="form-check form-group">
                                <input type="radio" name="diabetes" value="1"> Có
                                <input type="radio" name="diabetes" value="0" checked> Không
                                <span class="form-message"></span>
                            </div>
                            
                            <br>
                            <div class="btn-box-dk">
                                <button type="submit">
                                    Đăng ký
                                </button>
                            </div>
                        </form>
                </td>
            </tr>
        </table>
        </div>
        </div>
    </main>
    
    <!-- validation-->
    <script src="../JavaScript/validation.js"></script>
    <script>
        validation({
            form: "#form-1",
            selectorParent: '.form-group',
            errorSelector: '.form-message',
            rules: [
                validation.isRequired('#emailRegister', 'Vui lòng nhập thông tin vào trường này'),
                validation.isEmail('#emailRegister', "Vui lòng nhập đúng định dạng Email"),

                validation.isRequired('#passRegister', 'Vui lòng nhập thông tin vào trường này'),
                validation.isPassLength('#passRegister', 6, "Mật khẩu phải có độ dài tối thiểu là 6 ký tự"),

                validation.isRequired('#pass', 'Vui lòng nhập thông tin vào trường này'),
                validation.isConfirmPass('#pass', function () {
                    var element = document.querySelector('#form-1 #passRegister');
                    return element.value;
                }, 'Vui lòng nhập mật khẩu chính xác'),
                validation.isRequired('#age', 'Vui lòng nhập tuổi của bạn'),
                validation.isRequired('#weight', 'Vui lòng nhập cân nặng của bạn(kg)'),
                validation.isRequired('#height', 'Vui lòng nhập chiểu cao của bạn(m)'),
                validation.isRequired('#cigsPerDay', 'Vui lòng nhập số điếu thuốc trên một ngày')
            ],
        });
    </script>
    
    <footer class="footer-distributed">

        <div class="footer-left">

            <h4>DAVDK<span>group</span></h4>

            <p class="footer-links">
                <a href="#" class="link-1">Trang chủ</a>

                <a href="#">Chúng tôi</a>

                <a href="#">Liên hệ</a>
            </p>

            <p class="footer-company-name">DAVDK © 2021</p>
        </div>

        <div class="footer-center">

            <div>
                <i class="fa fa-map-marker"></i>
                <p><span>Đại học Bách Khoa Đà Nẵng</span> Liên Chiểu, Đà Nẵng</p>
            </div>

            <div>
                <i class="fa fa-phone"></i>
                <p>+8423345779</p>
            </div>

            <div>
                <i class="fa fa-envelope"></i>
                <p><a href="mailto:support@company.com">heartrate4124@gmail.com</a></p>
            </div>

        </div>

        <div class="footer-right">

            <p class="footer-company-about">
                <span>Về Chúng tôi</span>
                DAVĐK luôn đồng hành cùng các bạn, nơi của trách nhiệm và chất lượng!
            </p>

            <div class="footer-icons">

                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-github"></i></a>

            </div>

        </div>

    </footer>
</body>

</html>