<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../styleCSS/tieude.css">
<header>
  <div id="menu">
    <ul>
      <li><a href="../View/user.php"><strong>Quản Lý</strong></a></li>
      <li><a href="../Controller/C_Accout.php?chitiet=<?php echo $_SESSION['code'] ?>" target="_self"><strong>Thông tin</strong></a></li>
      <li><a href="../Controller/C_UserRecord.php?id=<?php echo $_SESSION['id']; ?>" target="_self"><strong>Gần đây</strong></a></li>
    </ul>
  </div>

</header>

</html>