<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../styleCSS/tieudequanli.css">
<header>
    <div id="menu">
        <ul>
            <li><a href="../View/quanli.php"><strong>Quản Lý</strong></a></li>
            <li><a href="../Controller/C_Accout.php?quanlidanhsach=danhsach" target="_self"><strong>Danh sách</strong></a></li>
            <li><a href="../View/themUser.php" target="_self"><strong>Thêm user</strong></a></li>
            <li><a href="../Controller/C_Accout.php?lichsudo=lichsu" target="_self"><strong>Lịch Sử Đo</strong></a></li>
            <input type="search" placeholder="Search">
        </ul>
    </div>

</header>

</html>