<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Quản lý</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="../styleCSS/login.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
		integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="../styleCSS/quanli.css" />

<body>

	<div class="container">
		<nav>
			<ul class="mcd-menu">
				<li>
					<a href="../Controller/C_Accout.php?chitiet=<?php echo $_SESSION['code'] ?>" class="active">
						<i class="fa fa-user"></i>
						<strong>cá nhân</strong>
						<small>user</small>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-cog"></i>
						<strong>cài đặt</strong>
						<small>user</small>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-refresh"></i>
						<strong>làm mới</strong>
						<small>user</small>
					</a>
				</li>
				<li>
					<a href="contact.php" target="_self">
						<i class="fa fa-envelope-o"></i>
						<strong>liên hệ</strong>
						<small>user</small>
					</a>
				</li>
				<li>
					<a href="../Controller/C_Accout.php?keyLogout=logout" target="_top">
						<i class="fa fa-sign-out"></i>
						<strong>đăng xuất</strong>
						<small>user</small>
					</a>
				</li>
			</ul>
		</nav>



	</div>
</body>

</html>