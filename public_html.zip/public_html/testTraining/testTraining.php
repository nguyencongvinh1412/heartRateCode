<?php
    // mo ket noi database
    $link = mysqli_connect("localhost","id16619114_heart_rate","heartRate-4124", "id16619114_heart_rate4124");
    if(!$link) {
        echo "Khong ket noi duoc";
    }
    else {
         echo "<div>Ket noi thanh cong</div>";
        
        $ret = mysqli_query($link, 'select * from datatest');
        $mTest = getMatrix($ret);

        $arrValue = array();
        $index = 0;

        for($i = 0; $i< count($mTest); $i++) {
            $arrValue[$index] = array();

            $male = $mTest[$i][0]; $age = $mTest[$i][1]; $smoker = $mTest[$i][3]; $bpmeds = $mTest[$i][4]; $prevalentStroke = $mTest[$i][5]; $prevalentHyp = $mTest[$i][6]; $diabetes = $mTest[$i][7]; $bmi = $mTest[$i][8]; $heart = $mTest[$i][9];
            // count samples
            $result = mysqli_query($link,"select count(*) from framingham");
            if(mysqli_num_rows($result) > 0) {
                $total = getValue($result);
            }

            // sick
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1");
            if(mysqli_num_rows($result) > 0) {
                $sick = getValue($result);
            }

            // male
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and male = '$male' ");
            if(mysqli_num_rows($result) > 0) {
                $sickMale = getValue($result);
            }

            //age
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and age = '$age' ");
            if(mysqli_num_rows($result) > 0) {
                $sickAge = getValue($result);
            }

            // smoker
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and currentSmoker ='$smoker' ");
            if(mysqli_num_rows($result) > 0) {
                $sickSmoker = getValue($result);
            }

            // bpmeds
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and BPMeds = '$bpmeds' ");
            if(mysqli_num_rows($result) > 0) {
                $sickBPMeds = getValue($result);
            }

            // prevalentStroke
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and prevalentStroke ='$prevalentStroke'");
            if(mysqli_num_rows($result) > 0) {
                $sickPrevalentStroke = getValue($result);
            }

            // prevalentHyp
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and prevalentHyp = '$prevalentHyp' ");
            if(mysqli_num_rows($result) > 0) {
                $sickPrevalentHyp = getValue($result);
            }

            // diabetes
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and diabetes = '$diabetes'");
            if(mysqli_num_rows($result) > 0) {
                $sickDiabetes = getValue($result);
            }

            // bmi
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and BMI = '$bmi'");
            if(mysqli_num_rows($result) > 0) {
                $sickBMI = getValue($result);
            }

            // heart
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 1 and heartRate = '$heart'");
            if(mysqli_num_rows($result) > 0) {
                $sickHeart = getValue($result);
            }
            

            /**----------------------- */
            // ko bệnh
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0");
            if(mysqli_num_rows($result) > 0) {
                $noSick = getValue($result);
            }

            // male
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and male = '$male' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickMale = getValue($result);
            }

            //age
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and age = '$age' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickAge = getValue($result);
            }

            // smoker
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and currentSmoker ='$smoker' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickSmoker = getValue($result);
            }

            // bpmeds
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and BPMeds = '$bpmeds' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickBPMeds = getValue($result);
            }

            // prevalentStroke
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and prevalentStroke ='$prevalentStroke'");
            if(mysqli_num_rows($result) > 0) {
                $noSickPrevalentStroke = getValue($result);
            }

            // prevalentHyp
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and prevalentHyp = '$prevalentHyp' ");
            if(mysqli_num_rows($result) > 0) {
                $noSickPrevalentHyp = getValue($result);
            }

            // diabetes
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and diabetes = '$diabetes'");
            if(mysqli_num_rows($result) > 0) {
                $noSickDiabetes = getValue($result);
            }

            // bmi
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and BMI = '$bmi'");
            if(mysqli_num_rows($result) > 0) {
                $noSickBMI = getValue($result);
            }

            // heart
            $result = mysqli_query($link,"select count(*) from framingham where TenYearCHD = 0 and heartRate = '$heart'");
            if(mysqli_num_rows($result) > 0) {
                $noSickHeart = getValue($result);
            }
            
            // sick
            $male = brobability($sickMale, $sick);
            $age = brobability($sickAge, $sick);
            $smoker = brobability($sickSmoker, $sick);
            $bpmeds = brobability($sickBPMeds, $sick);
            $prevalentStroke = brobability($sickPrevalentStroke, $sick);
            $prevalentHyp = brobability($sickPrevalentHyp, $sick);
            $diabetes = brobability($sickDiabetes, $sick);
            $bmi = brobability($sickBMI, $sick);
            $heart = brobability($sickHeart, $sick);

            $tick = $male * $age * $smoker * $bpmeds * $prevalentStroke * $prevalentHyp * $diabetes * $bmi * $heart;
            $retSick = $tick * $sick / $total;

            // No sick
            $male = brobability($noSickMale,$noSick);
            $age = brobability($noSickAge,$noSick);
            $smoker = brobability($noSickSmoker,$noSick);
            $bpmeds = brobability($noSickBPMeds,$noSick);
            $prevalentStroke = brobability($noSickPrevalentStroke,$noSick);
            $prevalentHyp = brobability($noSickPrevalentHyp,$noSick);
            $diabetes = brobability($noSickDiabetes,$noSick);
            $bmi = brobability($noSickBMI,$noSick);
            $heart = brobability($noSickHeart,$noSick);

            $tick = $male * $age * $smoker * $bpmeds * $prevalentStroke * $prevalentHyp * $diabetes * $bmi * $heart;
            $retNoSick = $tick * $noSick / $total;

            $arrValue[$index] = $mTest[$i];

            if($retSick > $retNoSick) $arrValue[$index][11] = 1;
            else $arrValue[$index][11] = 0;

            $index++;

        }
        mysqli_close($link);
    }
    
    function brobability($x, $xi) {
        $ret = 1.0*($x + 1)/ ($xi + 9);
        return $ret;
    }
    
    function getValue($data) {
        $returnMatrix = array();
        $i = 0;
        while($row = mysqli_fetch_array($data)) {
            $returnMatrix[$i] = array();
            for($j =0 ; $j < count($row)/2; $j++) {
                $returnMatrix[$i][$j] = $row[$j];
            }
            $i++;
        }
        return $returnMatrix[0][0];
    }
    
    function getMatrix($data) {
        $returnMatrix = array();
        $i = 0;
        while($row = mysqli_fetch_array($data)) {
            $returnMatrix[$i] = array();
            for($j =0 ; $j < count($row)/2; $j++) {
                $returnMatrix[$i][$j] = $row[$j];
            }
            $i++;
        }
        return $returnMatrix;
    }
    
    function showMatrix($data) {
        foreach($data as $row) {
            foreach($row as $val) {
                echo $val . "&nbsp&nbsp&nbsp";
            }
            echo "<br>";
        }
    }
    
    function getArray($data) {
        $returnArr = array();
        $i = 0;
        while($row = mysqli_fetch_array($data)) {
            for($i = 0; $i < count($row)/2; $i++) {
                $returnArr[$i] = $row[$i];
            }
        }
        return $returnArr;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
	<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</head>
<body>
    
    <form action="">
        <table class="table" style="margin:auto; width:80%;">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>male</th>
                    <th>age</th>
                    <th>CigsPerDay</th>
                    <th>BPMeds</th>
                    <th>PrevalentStroke</th>
                    <th>PrevalentHyp</th>
                    <th>Diabetes</th>
                    <th>BMI</th>
                    <th>heartRate</th>
                    <th>Original Value</th>
                    <th>Prediction</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 1;
                    $rate = 0;
                    foreach ($arrValue as $row) {
                        if($row[10] != $row[11]) {
                            echo
                            "   
                                <tr class=\"table-warning\">
                                    <td>$stt</td>
                                    <td>$row[0]</td>
                                    <td>$row[1]</td>
                                    <td>$row[3]</td>
                                    <td>$row[4]</td>
                                    <td>$row[5]</td>
                                    <td>$row[6]</td>
                                    <td>$row[7]</td>
                                    <td>$row[8]</td>
                                    <td>$row[9]</td>
                                    <td>$row[10]</td>
                                    <td>$row[11]</td>
                                </tr>
                            ";
                        }
                        else {
                            $rate++;
                            echo
                            "   
                                <tr class=\"table-primary\">
                                    <td>$stt</td>
                                    <td>$row[0]</td>
                                    <td>$row[1]</td>
                                    <td>$row[3]</td>
                                    <td>$row[4]</td>
                                    <td>$row[5]</td>
                                    <td>$row[6]</td>
                                    <td>$row[7]</td>
                                    <td>$row[8]</td>
                                    <td>$row[9]</td>
                                    <td>$row[10]</td>
                                    <td>$row[11]</td>
                                </tr>
                            ";
                        }
                        $stt++;
                    }
                ?>
                <tr>
                    <td>Xác suất đúng</td>
                    <td></td>
                    <td><?php echo round($rate*100/($stt-1), 2) . '%' ?></td>
                </tr>
            </tbody>
        </table>
    </form>

</body>
</html>